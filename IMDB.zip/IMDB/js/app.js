window.addEventListener("load", () => {

    $('#searchmovie').on('submit', (e) => {
        let moviename = $("#moviename").val();
        //console.log(moviename);
        getMovieInfo(moviename);
        e.preventDefault();
    });
});
function getMovieInfo(moviename)
{
    let name = moviename;
    const movieAPI = "https://www.omdbapi.com/?s=" + name.toString() +"&apikey=e99f1cc5";
    fetch(movieAPI)
        .then(response => {
            return response.json();
        })
    .then(data => {
        console.log(data);
        let movies = data.Search;
        var error = data.Error;
        if (error!=null)
        {
            var length = error.length;
        }
        let outPut = '';
        if (length > 1) {
            outPut += `<h4 style="text-align:center;">Sorry!!! Movie not found...</h4>`;
            $("#movies").html(outPut);
        }
        else {
            $.each(movies, (index, movie) => {
                /*alert(movie.Title);*/
                outPut += `
            <div class="col-md-3">
            <div class="well text-center">
            <img src="${movie.Poster}">
            <h5>${movie.Title}</h5>
            <a onclick="movieSelected('${movie.imdbID}')" class="btn btn-primary" href="#">Movie Details</a>
             </div>
            </div>
            `;
            })
            // alert(outPut);
            $("#movies").html(outPut);
        }
        })
}

function movieSelected(id) {
    sessionStorage.setItem("movieID", id);
    window.location.href = 'movie.html';
    return false;
}

function getMovie() {
    var ID = sessionStorage.getItem('movieID');
    const movieAPIById = "https://www.omdbapi.com/?i=" + ID + "&apikey=e99f1cc5";
    fetch(movieAPIById)
        .then(response => {
            return response.json();
        })
        .then(data => {
            console.log(data);
            let Poster = data.Poster;
            let Actors = data.Actors;;
            let Director = data.Director;;
            let Genre = data.Genre;;
            let Language = data.Language;;
            let Year = data.Year;;
            let imdbRating = data.imdbRating;
            let Title = data.Title;
            let Awards = data.Awards;
            let Plot = data.Plot;
           /*Actors, Director, Genre, Language, Year, imdbRating*/
        
            let out =`
<div class ="row">
<div class ="col-md-4">
<img src="${Poster}" class="thumbnail">
</div>
<div class="col-md-8">
<h2>${Title}</h2>
<ul class="list-group">
<li class="list-group-item"><strong>Genre:</strong>${Genre}</li>
<li class="list-group-item"><strong>Language:</strong>${Language}</li>
<li class="list-group-item"><strong>Year:</strong>${Year}</li>
<li class="list-group-item"><strong>imdbRating:</strong>${imdbRating}</li>
<li class="list-group-item"><strong>Actors:</strong>${Actors}</li>
<li class="list-group-item"><strong>Director:</strong>${Director}</li>
<li class="list-group-item"><strong>Awards:</strong>${Awards}</li>
</ul>
</div>
</div>
<div class="row">
<div class="well">
<h3> Plot: </h3>
${Plot}
<hr>
<a href="https://www.imdb.com/title/${ID}" target="_blank" class="btn btn-primary">View IMDB</a>
<a href="index.html" class="btn btn-default">Go Back To Search</a>
</div>
</div>
`;
            $('#movie').html(out);
        })

}